#include "EnemyFactory.h"


EnemyFactory::EnemyFactory(void)
{
}


EnemyFactory::~EnemyFactory(void)
{
}
