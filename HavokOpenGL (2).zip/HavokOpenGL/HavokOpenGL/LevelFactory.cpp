#include "LevelFactory.h"


LevelFactory::LevelFactory(void)
{
}


LevelFactory::~LevelFactory(void)
{
}
