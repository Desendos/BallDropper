#pragma once
#include "enemy.h"
class EnemySmall :
	public Enemy
{
public:
	EnemySmall(void);
	~EnemySmall(void);
	void output();
};

